<style>
    * {
        background-color: rgb(31, 31, 40);
        color: white;
        text-align: center;
        font-weight: 1000;
        font-size: larger;
    }

    h1 {
        font-weight: 500;
        color: #504070;
    }
</style>